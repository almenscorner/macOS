# Build & Deploy materials 

Those scripts let you build an Octory package to upload to your MDM and then to deploy this Octory package.