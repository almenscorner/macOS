#!/bin/bash
# to be executed when Octory has just succesffully completed

#Unload and remove LaunchAgent

launchctl unload /Library/LaunchAgents/com.amaris.octory.launch.plist
rm /Library/LaunchAgents/com.amaris.octory.launch.plist

#Unload and remove helper

launchctl unload /Library/LaunchDaemons/com.amaris.octory.helper.plist
rm /Library/LaunchDaemons/com.amaris.octory.helper.plist
rm /Library/PrivilegedHelperTools/com.amaris.octory.helper

#Remove Octory

rm -r /Library/Application\ Support/Octory

#Write OctoryDone file

loggedInUser=$( echo "show State:/Users/ConsoleUser" | scutil | awk '/Name :/ && ! /loginwindow/ { print $3 }' )

touch "/Users/$loggedInUser/Library/Preferences/.OctoryDone"